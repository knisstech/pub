RUINS OF STONE
==============

HOW TO PLAY
  Windows   double-click RuinsOfStone.exe
  Linux     open a terminal in this folder and run
              chmod +x RuinsOfStone.x86_64
              ./RuinsOfStone.x86_64

  Nothing to install - no game engine needed.

  The first time, Windows may show "Windows protected your PC". That
  happens with any program without a paid code signature. Click "More
  info" then "Run anyway".

  The firewall will ask for permission the first time you host a network
  game. Tick "Private networks".

GRAPHICS
  The game opens on High. If it stutters, press F1 for an instant drop to
  Low, or pick Low / Medium at the top left of the title screen.

  The lighting effects (ambient occlusion, wet-street reflections,
  volumetric fog) need a graphics card with Vulkan. If the game refuses to
  start at all, run it from a terminal with:
      RuinsOfStone.exe --rendering-driver opengl3
  It then starts on any card, but without those effects.

LANGUAGE
  The game opens in English. Portuguese is also available: the switch is
  at the top right of the title screen, and your choice is remembered for
  next time.

CONTROLS
  Player 1   WASD + mouse, left button shoots, Q ability, E talk
  Player 2   arrow keys, right Ctrl shoots, numpad 0 ability, Enter talk
  Players 3 and 4   gamepad (sticks, RB shoots, B ability, X talk)

  J   quests        H   on-screen help
  F1  light mode (if the game stutters)
  F5 / F9   save / load
  Esc  release the mouse (click the screen to go back)

UP TO 4 PLAYERS
  Same screen: pick how many on the title screen.
  Two computers on the same network: one clicks "Host" and reads out the
  IP shown; the other types that IP and clicks "Join".

--------------------------------------------------------------------

COMO JOGAR
  Windows   clique duas vezes em RuinsOfStone.exe
  Linux     abra um terminal nesta pasta e rode
              chmod +x RuinsOfStone.x86_64
              ./RuinsOfStone.x86_64

  Nao precisa instalar nada - nem a Godot.

  Na primeira vez o Windows pode mostrar "O Windows protegeu o seu PC".
  Isso acontece com qualquer programa sem assinatura digital paga.
  Clique em "Mais informacoes" e depois em "Executar assim mesmo".

  O firewall vai pedir permissao na primeira vez que voce hospedar uma
  partida em rede. Marque "Redes privadas".

GRAFICO
  O jogo abre no nivel Alto. Se engasgar, aperte F1 para cair no Baixo na
  hora, ou escolha Baixo / Medio no canto superior esquerdo da tela inicial.

  Os efeitos de luz (oclusao de ambiente, reflexo na rua molhada, neblina
  com volume) precisam de placa de video com Vulkan. Se o jogo nem abrir,
  rode pelo terminal com:
      RuinsOfStone.exe --rendering-driver opengl3
  Assim ele abre em qualquer placa, so que sem esses efeitos.

IDIOMA
  O jogo abre em ingles. O portugues continua disponivel: a troca fica no
  canto superior direito da tela inicial e e guardada para a proxima vez.

CONTROLES
  Jogador 1   WASD + mouse, botao esquerdo atira, Q habilidade, E conversa
  Jogador 2   setas, Ctrl direito atira, 0 do teclado numerico habilidade,
              Enter conversa
  Jogadores 3 e 4   controle (analogicos, RB atira, B habilidade, X conversa)

  J   missoes          H   ajuda na tela
  F1  modo leve (se o jogo engasgar)
  F5 / F9   salvar / carregar
  Esc  libera o mouse da janela (clique na tela para voltar)

ATE 4 JOGADORES
  Na mesma tela: escolha a quantidade na tela inicial.
  Em dois computadores da mesma rede: um clica em "Hospedar" e diz o IP
  que aparece; o outro digita esse IP e clica em "Entrar".
